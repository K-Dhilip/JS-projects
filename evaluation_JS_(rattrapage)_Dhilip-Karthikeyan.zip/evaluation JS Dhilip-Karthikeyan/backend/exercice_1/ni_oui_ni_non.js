let quotes = ["Tu es prêt à jouer à ce jeu ?",
"Tu veux jouer à ce jeu avec moi ?",
"Tu peux me redire de quoi on parlait à l'instant ? … Tu es sur ?",
"Ouah mais tu es trop fort, tu t'es beaucoup entraîner à ce jeu ?",
"Ah tu as perdu !",
"Tu ne veux pas te mêler de tes affaires ?",
"Je t'aime beaucoup, et toi ?",
"Est-ce que tu fais souvent preuve d’imagination ?",
"Sais-tu ce qu'il y a juste derrière toi ?",
"J'ai un trou de mémoire, on joue à quel jeu déjà ?",
"Quel est le but de ce jeu ?",
"Tu as perdu ! (=>alors que cela n'est pas vrai, cela déstabilisera votre adversaire!)",
"Tu mens !",
"Tu rigoles ?",
"Je fais du koupsing en sport, et toi tu pratiques un sport ?",
"Est-ce que tu sais faire du vélo en pédalant avec les mains ?",
"Comment appelle-t-on les personnes qui ne fument pas ? ",
"Je surfe beaucoup sur la toile, et toi tu aimes te faire des toiles ?",
"Tu étais au courant de la dernière nouvelle ?",
];
let generate

function display(){
 generate = quotes[Math.floor(quotes.length * Math.random())];
 document.getElementById('output').innerHTML=generate;
}

function game()
{
var input1 =document.getElementById("test");

if((input1.value=="")){
    document.getElementById('error').innerHTML= 'saisissez correctement votre réponse 🤬😡 ';
}
else if((input1.value=="oui")||(input1.value=="non"))
{
document.getElementById('error').innerHTML= 'Perdre 😥 ';
}
else
{
document.getElementById('error').innerHTML= 'Gagner 🎉🏆😎';

}



}

